/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package enums;

/**
 *
 * @author Eugenio Domingos
 */
//Lista dos tipos de estados de um transportes
public enum EstadoTransporte {
    Pendente, Finalizado, Cancelado, Transportando;

}
